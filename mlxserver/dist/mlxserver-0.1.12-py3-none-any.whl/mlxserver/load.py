from mlx_lm.utils import load

def load_model(model):
    return load(model)