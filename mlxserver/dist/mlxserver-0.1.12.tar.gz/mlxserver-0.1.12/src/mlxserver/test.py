from server import MLXServer

MLXServer("mlx-community/Nous-Hermes-2-Mistral-7B-DPO-4bit-MLX")